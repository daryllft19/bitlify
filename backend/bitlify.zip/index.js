const axios = require('axios');

axios.get('www.google.com').then( res => {
  console.log(res);
});

